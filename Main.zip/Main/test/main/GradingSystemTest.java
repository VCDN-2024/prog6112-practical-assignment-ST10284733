package main;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

public class GradingSystemTest {

    @Test
    public void testAddStudent() {
        GradingSystem gradingSystem = new GradingSystem();
        double[] grades = {85.0, 90.0, 95.0};
        Student student = new Student("Joe bloggs", grades);
        gradingSystem.addStudent(student);

        
        assertEquals(1, gradingSystem.getAverageGrade().size());
        assertEquals("Joe bloggs", gradingSystem.getAverageGrade().get(0).getName());
    }

    @Test
    public void testGenerateReport() {
        GradingSystem gradingSystem = new GradingSystem();
        double[] grades1 = {85.0, 90.0, 95.0};
        double[] grades2 = {75.0, 80.0, 70.0};
        gradingSystem.addStudent(new Student("Jane Doe", grades1));
        gradingSystem.addStudent(new Student("John Smith", grades2));
        
        assertDoesNotThrow(() -> gradingSystem.generateReport());
    }
}
