package main;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class StudentTest {

    @Test
    public void testGetAverageGrade() {
        double[] grades = {90.0, 80.0, 70.0};
        Student student = new Student("John Doe", grades);
        assertEquals(80.0, student.getAverageGrade());
    }
}
