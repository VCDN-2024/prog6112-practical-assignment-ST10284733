package main;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        
         Scanner scanner = new Scanner(System.in);
        GradingSystem gradingSystem = new GradingSystem();
        
        while (true) {
            System.out.println("Student Grading System");
            System.out.println("1. Add Student");
            System.out.println("2. Generate Report");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();
            
            if (choice == 1) {
                System.out.print("Enter student name: ");
                String name = scanner.nextLine();
                System.out.print("Enter number of grades: ");
                int numGrades = scanner.nextInt();
                double[] grades = new double[numGrades];
                for (int i = 0; i < numGrades; i++) {
                    System.out.print("Enter grade " + (i + 1) + ": ");
                    grades[i] = scanner.nextDouble();
                }
                scanner.nextLine();
                
                Student student = new Student(name, grades);
                gradingSystem.addStudent(student);
                System.out.println("Student added successfully.");
            } else if (choice == 2) {
                gradingSystem.generateReport();
            } else if (choice == 3) {
                break;
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        }
        
        scanner.close();
    }
}

//Refrence List 
//Student materials PROG6112_A1.docx
//Unit Test File/How to Video(Fatima)
//W3Schools
