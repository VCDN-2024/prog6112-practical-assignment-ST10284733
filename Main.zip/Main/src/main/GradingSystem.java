package main;

import java.util.ArrayList;


public class GradingSystem {
    
    private ArrayList<Student> students;

    public GradingSystem() {
        students = new ArrayList<>();
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public void generateReport() {
        System.out.println("Student Grading Report");
        System.out.printf("%-20s %s\n", "Student Name", "Average Grade");
        for (Student student : students) {
            System.out.printf("%-20s %.2f\n", student.getName(), student.getAverageGrade());
        }
    }
    
}
