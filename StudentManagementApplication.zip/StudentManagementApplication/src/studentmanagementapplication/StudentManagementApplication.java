package studentmanagementapplication;

import java.util.InputMismatchException;
import java.util.Scanner;

public class StudentManagementApplication {
        private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
         while (true) {
            showMenu();
            String choice = scanner.nextLine();
            switch (choice) {
                case "1":
                    captureStudent();
                    break;
                case "2":
                    searchStudent();
                    break;
                case "3":
                    deleteStudent();
                    break;
                case "4":
                    Student.studentReport();
                    break;
                case "5":
                    System.out.println("Exiting application...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Exiting application...");
                    System.exit(0);
                    break;
            }
        }
    }

         private static void showMenu() {
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        System.out.println("Please select one of the following menu items:");
        System.out.println("(1) - Capture a new Student");
        System.out.println("(2) - Search for a Student");
        System.out.println("(3) - Delete a Student");
        System.out.println("(4) - Print Student report");
        System.out.println("(5) - Exit Application");
        System.out.print("Enter your choice: ");
    }

    private static void captureStudent() {
        System.out.println("CAPTURE A NEW STUDENT");
        System.out.print("Enter the Student id: ");
        String studentId = scanner.nextLine();
        System.out.print("Enter Student name: ");
        String name = scanner.nextLine();
        int age = -1;
        while (age < 16) {
            System.out.print("Enter Student age: ");
            try {
                age = Integer.parseInt(scanner.nextLine());
                if (age < 16) {
                    System.out.println("You have entered an incorrect Student age!!!");
                    System.out.println("Please re-enter the student age");
                }
            } catch (NumberFormatException e) {
                System.out.println("You have entered an incorrect Student age!");
                System.out.println("Please re-enter the student age");
            }
        }
        System.out.print("Enter the student email: ");
        String email = scanner.nextLine();
        System.out.print("Enter the student course: ");
        String course = scanner.nextLine();
        
        Student student = new Student(studentId, name, age, email, course);
        Student.saveStudent(student);
    }

    private static void searchStudent() {
        System.out.print("Enter the Student id to search: ");
        String studentId = scanner.nextLine();
        Student.searchStudent(studentId);
    }

    private static void deleteStudent() {
        System.out.print("Enter the Student id to delete: ");
        String studentId = scanner.nextLine();
        System.out.print("Are you sure you want to delete Student " + studentId + " from the system? Yes (y) to delete: ");
        String confirmation = scanner.nextLine();
        if (confirmation.equalsIgnoreCase("y")) {
            Student.deleteStudent(studentId);
        } else {
            System.out.println("Student deletion cancelled.");
        }
    }
}

//Refrence List 
//Student materials PROG6112_A1.docx
//Unit Test File/How to Video(Fatima)
//W3Schools