package studentmanagementapplication;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Student {
    
    private String studentId;
    private String name;
    private int age;
    private String email;
    private String course;
    
    private static List<Student> Students = new ArrayList<>();
    
    public Student(String studentId, String name, int age, String email, String course) {
        this.studentId = studentId;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }
    
    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public static void saveStudent(Student student) {
        Students.add(student);
        System.out.println("Student details have been successfully saved.");
    }

    public static void searchStudent(String studentId) {
        for (Student student : Students) {
            if (student.getStudentId().equals(studentId)) {
                System.out.println("STUDENT ID: " + student.getStudentId());
                System.out.println("STUDENT NAME: " + student.getName());
                System.out.println("STUDENT AGE: " + student.getAge());
                System.out.println("STUDENT EMAIL: " + student.getEmail());
                System.out.println("STUDENT COURSE: " + student.getCourse());
                return;
            }
        }
        System.out.println("Student with Student Id: " + studentId + " was not found!");
    }

    public static void deleteStudent(String studentId) {
        Iterator<Student> iterator = Students.iterator();
        while (iterator.hasNext()) {
            Student student = iterator.next();
            if (student.getStudentId().equals(studentId)) {
                iterator.remove();
                
                System.out.println("Student with Student Id: " + studentId + " WAS deleted!");
                
                return;
            }
        }
        System.out.println("Student with Student Id: " + studentId + " was not found!");
    }

    public static void studentReport() {
        int count = 1;
        for (Student student : Students) {
            System.out.println("STUDENT " + count++);
            System.out.println("STUDENT ID: " + student.getStudentId());
            System.out.println("STUDENT NAME: " + student.getName());
            System.out.println("STUDENT AGE: " + student.getAge());
            System.out.println("STUDENT EMAIL: " + student.getEmail());
            System.out.println("STUDENT COURSE: " + student.getCourse());
        }
    }
}

