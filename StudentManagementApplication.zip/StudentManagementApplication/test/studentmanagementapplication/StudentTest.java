package studentmanagementapplication;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class StudentTest {

    private final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    private final PrintStream originalSystemOut = System.out;

    @BeforeEach
    public void setUp() {
        System.setOut(new PrintStream(outputStream));

    }

    @AfterEach
    public void tearDown() {
        System.setOut(originalSystemOut);
    }

    @Test
    public void testSaveStudent() {
        Student student = new Student("10111", "Joe Bloggs", 19, "joe.bloggs@gmail.com", "disd");
        Student.saveStudent(student);
        
        List<Student> students = Student.getStudents();
        assertEquals(1, students.size());
        assertEquals("10111", students.get(0).getStudentId());
    }

    @Test
    public void testSearchStudent() {
        Student student = new Student("10112", "John Doe", 21, "john.doe@gmail.com", "disd");
        Student.saveStudent(student);
        
        Student.searchStudent("10112");
        String output = outputStream.toString().trim();
        assertTrue(output.contains("STUDENT ID: 10112"));
        assertTrue(output.contains("STUDENT NAME: John Doe"));
        assertTrue(output.contains("STUDENT AGE: 21"));
        assertTrue(output.contains("STUDENT EMAIL: john.doe@gmail.com"));
        assertTrue(output.contains("STUDENT COURSE: disd"));
    }

    @Test
    public void testDeleteStudent() {
        Student student = new Student("10113", "Peter Parker", 20, "spidey@gmail.com", "disn");
        Student.saveStudent(student);
        
        Student.deleteStudent("S003");
        assertEquals(0, Student.getStudents().size());
        
        String output = outputStream.toString().trim();
        assertTrue(output.contains("Student with Student Id: S003 WAS deleted!"));
    }

    @Test
    public void testStudentReport() {
        Student student1 = new Student("10114", "Bruce Brown", 21, "bruce.brown@gmail.com", "disn");
        Student student2 = new Student("10115", "Chase Black", 23, "chase.black@gmail.com", "disd");
        Student.saveStudent(student1);
        Student.saveStudent(student2);
        
        Student.studentReport();
        String output = outputStream.toString().trim();
        
        assertTrue(output.contains("STUDENT 1"));
        assertTrue(output.contains("STUDENT ID: 10114"));
        assertTrue(output.contains("STUDENT NAME: Bruce Brown"));
        assertTrue(output.contains("STUDENT AGE: 21"));
        assertTrue(output.contains("STUDENT EMAIL: bruce.brown@gmail.com"));
        assertTrue(output.contains("STUDENT COURSE: disn"));
        assertTrue(output.contains("STUDENT 2"));
        assertTrue(output.contains("STUDENT ID: 10115"));
        assertTrue(output.contains("STUDENT NAME: Chase Black"));
        assertTrue(output.contains("STUDENT AGE: 23"));
        assertTrue(output.contains("STUDENT EMAIL: chase.black@example.com"));
        assertTrue(output.contains("STUDENT COURSE: disd"));
    }
}
